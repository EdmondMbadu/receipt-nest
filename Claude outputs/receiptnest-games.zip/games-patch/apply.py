"""Wire the static games into ReceiptNest's sitemap, SEO check, hosting headers, and footer.
Run from the repo root: python3 apply.py <path-to-patch-dir>"""
import json, sys, shutil, os
P = sys.argv[1]
def edit(path, pairs):
    s = open(path).read(); o = s
    for a, b in pairs:
        if b in s: continue            # already applied
        assert a in s, f'{path}: anchor not found: {a[:60]!r}'
        s = s.replace(a, b, 1)
    if s != o: open(path, 'w').write(s); print('updated', path)
    else: print('unchanged', path)
shutil.copy(os.path.join(P, 'game-pages.ts'), 'src/app/content/game-pages.ts'); print('wrote src/app/content/game-pages.ts')
edit('scripts/generate-sitemap.mjs', [
  ("import { blogPosts } from '../src/app/features/blog/blog-posts.ts';",
   "import { blogPosts } from '../src/app/features/blog/blog-posts.ts';\nimport { gamePages } from '../src/app/content/game-pages.ts';"),
  ("  ...blogPosts.map(post => ({ path: post.path, updated: post.dateModified }))\n];",
   "  ...blogPosts.map(post => ({ path: post.path, updated: post.dateModified })),\n  ...gamePages.map(page => ({ path: page.path, updated: page.updated }))\n];"),
])
edit('scripts/check-seo.mjs', [
  ("import { existsSync, readFileSync } from 'node:fs';", "import { existsSync, readFileSync, statSync } from 'node:fs';"),
  ("import { getBlogEditorial } from '../src/app/features/blog/blog-editorial.ts';",
   "import { getBlogEditorial } from '../src/app/features/blog/blog-editorial.ts';\nimport { gamePages } from '../src/app/content/game-pages.ts';"),
  ("  ...blogPosts.map(post => ({ ...post, title: post.seoTitle + ' | ReceiptNest' }))\n];",
   "  ...blogPosts.map(post => ({ ...post, title: post.seoTitle + ' | ReceiptNest' })),\n  ...gamePages\n];"),
  ("console.log('SEO checks passed: '",
   "for (const page of gamePages) {\n  const size = statSync(join(root, page.path, 'index.html')).size;\n  assert.ok(size < 120000, page.path + ': standalone game page must stay under 120 KB (is ' + size + ' bytes)');\n}\nconsole.log('SEO checks passed: '"),
])
fj = json.load(open('firebase.json'))
h = fj['hosting']['headers']
rules = [
  {"source": "/games/_shared/**", "headers": [{"key": "Cache-Control", "value": "public, max-age=31536000, immutable"}]},
  {"source": "/games/**/*.@(png|jpg|jpeg|webp|svg)", "headers": [{"key": "Cache-Control", "value": "public, max-age=86400"}]},
]
srcs = [r['source'] for r in h]
added = 0
for r in rules:
    if r['source'] not in srcs:
        i = srcs.index('/assets/**/*.@(png|jpg|jpeg|webp|svg|avif)') + 1 + added
        h.insert(i, r); added += 1
if added:
    open('firebase.json', 'w').write(json.dumps(fj, indent=2) + '\n'); print('updated firebase.json (+%d header rules)' % added)
else: print('unchanged firebase.json')
edit('src/app/components/public-layout/public-footer.component.html', [
  ('        <li><a routerLink="/pricing" class="hover:underline">Pricing</a></li>',
   '        <li><a routerLink="/pricing" class="hover:underline">Pricing</a></li>\n        <li><a href="/games" class="hover:underline">Games</a></li>'),
])
print('done')
