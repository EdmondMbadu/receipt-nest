"""Adds Snap vs Pile to the ReceiptNest repo. Run from the repo root:  python3 apply_snap_vs_pile.py
Copies public/games/snap-vs-pile/ (sitting next to this script) into the repo and registers the game:
game-pages.ts, GAME_IDS, admin stats panel, KNOWN_GAMES, games hub (new top card), cross-links from The Pile and Escape.
Safe to run twice: every edit checks whether it is already there. Then run: npm run seo:sitemap"""
import os, shutil, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.getcwd()
if not os.path.exists(os.path.join(ROOT, 'src/app/content/game-pages.ts')): sys.exit('Run this from the receipt-nest repo root.')
src = os.path.join(HERE, 'public/games/snap-vs-pile'); dst = os.path.join(ROOT, 'public/games/snap-vs-pile')
if os.path.abspath(src) != os.path.abspath(dst): shutil.copytree(src, dst, dirs_exist_ok=True)
print('copied public/games/snap-vs-pile')
def edit(path, old, new, done_marker):
    p = os.path.join(ROOT, path); s = open(p).read()
    if done_marker in s: print('already done:', path); return
    if old not in s: print('!! could not find the spot in', path, '-> edit by hand'); return
    open(p, 'w').write(s.replace(old, new, 1)); print('edited', path)
edit('src/app/content/game-pages.ts', "  {\n    path: '/games/pile',", """  {
    path: '/games/snap-vs-pile', kind: 'game', label: 'Snap vs Pile', updated: '2026-11-04',
    title: 'Snap vs Pile: Can the Phone Clear the Box? | ReceiptNest',
    description: 'Yellow snaps receipts, red adds them, and whoever leads grows. Watch the duel or take control of yellow, set to the Turkish March. Then learn to beat a backlog.'
  },
  {
    path: '/games/pile',""", "/games/snap-vs-pile")
edit('functions/src/game-stats-core.ts', '"pile", "decoder"]', '"pile", "versus", "decoder"]', '"versus"')
edit('src/app/features/admin/game-stats-panel.component.ts', "  { id: 'pile', label: 'The Pile', short: 'Pile' }", "  { id: 'pile', label: 'The Pile', short: 'Pile' },\n  { id: 'versus', label: 'Snap vs Pile', short: 'Versus' }", "'versus'")
edit('src/app/utils/signup-analytics.ts', "'pile', 'decoder'", "'pile', 'versus', 'decoder'", "'versus'")
H = 'public/games/index.html'
edit(H, '"itemListElement":[{"@type":"ListItem","position":1,"url":"https://receipt-nest.com/games/pile","name":"The Pile"},{"@type":"ListItem","position":2,"url":"https://receipt-nest.com/games/escape","name":"Escape the Year"},{"@type":"ListItem","position":3,"url":"https://receipt-nest.com/games/charge","name":"Guess the Charge"},{"@type":"ListItem","position":4,"url":"https://receipt-nest.com/games/shoebox","name":"Shoebox Sort"},{"@type":"ListItem","position":5,"url":"https://receipt-nest.com/games/fade","name":"Before It Fades"}]',
     '"itemListElement":[{"@type":"ListItem","position":1,"url":"https://receipt-nest.com/games/snap-vs-pile","name":"Snap vs Pile"},{"@type":"ListItem","position":2,"url":"https://receipt-nest.com/games/pile","name":"The Pile"},{"@type":"ListItem","position":3,"url":"https://receipt-nest.com/games/escape","name":"Escape the Year"},{"@type":"ListItem","position":4,"url":"https://receipt-nest.com/games/charge","name":"Guess the Charge"},{"@type":"ListItem","position":5,"url":"https://receipt-nest.com/games/shoebox","name":"Shoebox Sort"},{"@type":"ListItem","position":6,"url":"https://receipt-nest.com/games/fade","name":"Before It Fades"}]',
     'games/snap-vs-pile","name"')
OLD_PILE = '''    <a class="feature" href="/games/pile" aria-label="Play The Pile">
      <div class="art">
        <span class="stamp">NEW</span>
        <img class="phone" src="/games/pile/card.webp" alt="The Pile: a ball of receipts filling a glowing ring, with a receipt counter and the dollars in the pile" width="420" height="782" fetchpriority="high">'''
NEW_CARDS = '''    <a class="feature" href="/games/snap-vs-pile" aria-label="Play Snap vs Pile">
      <div class="art">
        <span class="stamp">NEW</span>
        <img class="phone" src="/games/snap-vs-pile/card.webp" alt="Snap vs Pile: a yellow phone ball and a red receipt ball fighting over a circle full of receipts, with a snapped versus in-the-pile score" width="420" height="782" fetchpriority="high">
      </div>
      <div class="txt">
        <div class="meta"><span class="chip">Watch or play</span><span class="chip">About 45 seconds</span><span class="chip">Free · no signup</span></div>
        <h2>Snap <span>vs pile</span></h2>
        <p>Yellow snaps every receipt it touches. Red drops one everywhere it goes. Whoever is ahead grows, so leads snowball and comebacks happen. Take control of yellow and clear the box.</p>
        <ul class="rules">
          <li><b>2</b>Balls: a phone that snaps, a pocket that piles up</li>
          <li><b>3</b>Dashes you can aim, refilling as you play</li>
          <li><b>♪</b>One note of the Turkish March per bounce, passed back and forth</li>
        </ul>
        <div class="dare">Can the phone clear the box?</div>
        <span class="play">Play now <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span>
      </div>
    </a>

    <a class="feature" href="/games/pile" aria-label="Play The Pile">
      <div class="art">
        <img class="phone" src="/games/pile/card.webp" alt="The Pile: a ball of receipts filling a glowing ring, with a receipt counter and the dollars in the pile" width="420" height="782" loading="lazy">'''
edit(H, OLD_PILE, NEW_CARDS, 'href="/games/snap-vs-pile" aria-label')
edit(H, '    <a href="/games/pile">The Pile</a>\n', '    <a href="/games/snap-vs-pile">Snap vs Pile</a>\n    <a href="/games/pile">The Pile</a>\n', '<a href="/games/snap-vs-pile">Snap vs Pile</a>\n    <a href="/games/pile">')
edit(H, '<a href="/games/pile">Play</a>', '<a href="/games/snap-vs-pile">Play</a>', '<a href="/games/snap-vs-pile">Play</a>')
for page in ('public/games/pile/index.html', 'public/games/escape/index.html'):
    edit(page, '<details><summary>Are there other games?</summary><p>Yes: ', '<details><summary>Are there other games?</summary><p>Yes: <a href="/games/snap-vs-pile">Snap vs Pile</a>, ', 'Yes: <a href="/games/snap-vs-pile">')
    edit(page, '    <a href="/games">Games</a>\n', '    <a href="/games">Games</a>\n    <a href="/games/snap-vs-pile">Snap vs Pile</a>\n', '<a href="/games/snap-vs-pile">Snap vs Pile</a>\n')
print('\nDone. Next: npm run seo:sitemap, then build, then deploy hosting + functions.')
